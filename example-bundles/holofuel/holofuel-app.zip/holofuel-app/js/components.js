
const HF_Symbol				= Vue.component('hf-symbol', {
    template: '<img src="/images/holo/holo-logo.png" style="height: .5em; vertical-align: middle;" />'
});

export default {
    HF_Symbol,
};
